package baseball;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

//랜덤생성 / 비교
public class con1_Base {

    public static int[] randomBall(int[] a) {

        List<Integer> numberList1 = IntStream.rangeClosed(0, 9)  // 0부터 9까지 숫자 생성
                .boxed()          // IntStream을 Integer로 변환
                .collect(Collectors.toList()); // List로 변환

        Collections.shuffle(numberList1); //컬렉션 섞음
        List<Integer> makeNum = numberList1.subList(0, 3); //3개 뽑음

        List<Integer> inputNum = Arrays.stream(a)   // IntStream 생성
                .boxed()             // Integer로 변환
                .collect(Collectors.toList()); // List로 변환

        System.out.println("당신이 입력한 값" + inputNum);
        System.out.println("만들어진 값" + makeNum);

        int[] check = new int[2];

        for (int i = 0; i < inputNum.size(); i++) {
            if (inputNum.get(i) == makeNum.get(i)) {
                check[0]++;
            }
        }

        HashSet<Integer> set1 = new HashSet<>(inputNum);
        HashSet<Integer> set2 = new HashSet<>(makeNum);
        set1.retainAll(set2); //교집합 찾음

        if (check[0] == 0) {
            check[1] = set1.size();
        } else {
            check[1] = set1.size() - check[0];
        }

        return check;
    }
}
