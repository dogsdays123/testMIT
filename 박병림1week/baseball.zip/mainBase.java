package baseball;

public class mainBase {
    public static void main(String[] args) {
        int[] inputNumbers = new int[args.length];

        for(int i = 0; i < args.length; i++) {
            inputNumbers[i] = Integer.parseInt(args[i]);
        }

        int[] checks = con1_Base.randomBall(inputNumbers);

        System.out.println("스트라이크 : " + checks[0] + " / 볼 : " + checks[1]);
    }
}
